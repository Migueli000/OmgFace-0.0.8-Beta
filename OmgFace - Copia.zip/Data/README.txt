Welcome to OmgFace version 0.0.8

What is this

this is a swf player of adobe flash you can open swf 
file to play animations or games

